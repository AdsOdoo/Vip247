# -*- coding: utf-8 -*-
# Part of Softhealer Technologies.


from . import send_whatsapp_message
from . import send_whatsapp_number

